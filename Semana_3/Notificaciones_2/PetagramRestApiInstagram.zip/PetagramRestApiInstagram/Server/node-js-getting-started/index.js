var express = require('express');
var app = express();

app.set('port', (process.env.PORT || 5000));

var bodyParser = require("body-parser");
app.use(bodyParser.json());  //soporte para codificar json
app.use(bodyParser.urlencoded({ extended: true })); //Soporte para decodificar las URL

var firebase = require("firebase");
firebase.initializeApp({
   serviceAccount: "Petagram-8c24570f1ea9.json",
   databaseURL: "https://petagram-b3a93.firebaseio.com"
   });

var FCM = require('fcm-push');
//var FCM = require('fcm-node');

app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function(request, response) {
  response.render('pages/index');
});


var tokenDeviceURI = "registrar-usuario";

//POST
//https://bibliotheque-croissant-44053.herokuapp.com/registrar-usuario
//token
//id_usuario
//id_foto
app.post("/" + tokenDeviceURI, function(request, response) {
  var token = request.body.token;
  var id_usuario = request.body.id_usuario;
  var id_foto = request.body.id_foto;
  
  var db = firebase.database();
  var tokenDevices = db.ref(tokenDeviceURI).push();
  tokenDevices.set({
         token: token,
         id_usuario: id_usuario,
         id_foto: id_foto
  });

  var path = tokenDevices.toString();
  var pathSplit = path.split(tokenDeviceURI + "/");
  var idAutoGenerado = pathSplit[1];

  var respuesta = generarRespuestaAToken(db, idAutoGenerado);
  response.setHeader("Content-Type", "application/json");
  response.send(JSON.stringify(respuesta));

//  response.send(request.body.token);
});

function generarRespuestaAToken(db, idAutoGenerado) {
    var respuesta = {};
    var usuario = "";
    var ref = db.ref("registrar-usuario");
    ref.on("child_added", function(snapshot, prevChildKey) {
        usuario = snapshot.val();
        respuesta = {
        id: idAutoGenerado,
        token: usuario.token,
        id_usuario: usuario.id_usuario,
        id_foto: usuario.id_foto
        };
    });
    return respuesta;

}

//GET
//https://bibliotheque-croissant-44053.herokuapp.com/toque-animal
//id
//animal
app.get("/toque-animal/:id/:id_usuario/:id_foto", function(request, response) {
    var id = request.params.id;
    var id_usuario = request.params.id_usuario;
    var id_foto = request.params.id_foto;

    var db = firebase.database();
    var ref = db.ref("registrar-usuario/" + id);
    var usuario = "";
    var respuesta = {};
    ref.on("value", function(snapshot) {
        usuario = snapshot.val();
        var mensaje = id_usuario + " te dio un toqueSITO";
        enviarNotificacion(usuario.token, mensaje);
        respuesta = {
            id: id,
            token: usuario.token,
            id_usuario: mensaje, //usuario.animal
            id_foto: usuario.id_foto
        };
        response.send(JSON.stringify(respuesta));
    }, function (errorObject) {
        console.log("The read failed: " + errorObject.code);
        respuesta = {
            id: "",
            token: "",
            id_usuario: "",
            id_foto: ""
        };
        response.send(JSON.stringify(respuesta));
    });
});


function enviarNotificacion(tokenDestinatario, mensaje) {
    var serverKey = 'AIzaSyAlLxsNAvpui0i-DFILzVRHHeqHGd2TwDk';
    var fcm = new FCM(serverKey);

var message = {
    to: tokenDestinatario, // required fill with device token or topics
    collapse_key: '',
    data: {},
    notification: {
        title: 'Notificacion desde Servidor',
        body: mensaje
    }
};

//callback style
fcm.send(message, function(err, response){
    if (err) {
        console.log("Something has gone wrong!");
    } else {
        console.log("Successfully sent with response: ", response);
    }
});

}


app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});


