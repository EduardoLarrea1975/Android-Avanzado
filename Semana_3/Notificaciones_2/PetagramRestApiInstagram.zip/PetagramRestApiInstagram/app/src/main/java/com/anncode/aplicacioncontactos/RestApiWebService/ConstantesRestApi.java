package com.anncode.aplicacioncontactos.RestApiWebService;

/**
 * Created by jlarrea on 18/07/2017.
 */
public final class ConstantesRestApi {
    public static final String ROOT_URL = "https://bibliotheque-croissant-44053.herokuapp.com/";
    public static final String KEY_POST_ID_TOKEN = "registrar-usuario";
    public static final String KEY_TOQUE_ANIMAL = "toque-animal/{id}/{id_usuario}/{id_foto}/";

}
