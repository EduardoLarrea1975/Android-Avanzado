package com.anncode.aplicacioncontactos.RestApiWebService.adapter;

import com.anncode.aplicacioncontactos.RestApiWebService.ConstantesRestApi;
import com.anncode.aplicacioncontactos.RestApiWebService.Endpoint;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by jlarrea on 19/07/2017.
 */
public class RestApiAdapter {

    public Endpoint establecerConexionRestApi() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ConstantesRestApi.ROOT_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    return retrofit.create(Endpoint.class);

    }
}
