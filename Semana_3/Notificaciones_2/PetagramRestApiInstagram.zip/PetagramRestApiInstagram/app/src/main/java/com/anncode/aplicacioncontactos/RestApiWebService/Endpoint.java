package com.anncode.aplicacioncontactos.RestApiWebService;

import com.anncode.aplicacioncontactos.model.UsuarioResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by jlarrea on 18/07/2017.
 */
public interface Endpoint {

    @FormUrlEncoded
    @POST(ConstantesRestApi.KEY_POST_ID_TOKEN)
    Call<UsuarioResponse> registrarTokenID(@Field("token") String token, @Field("id_usuario") String animal, @Field("id_foto") String id_foto);

    @GET(ConstantesRestApi.KEY_TOQUE_ANIMAL)
    Call<UsuarioResponse> toqueAnimal(@Path("id") String id, @Path("id_usuario") String id_usuario, @Path("id_foto") String id_foto);
}
