package com.anncode.aplicacioncontactos.model;

/**
 * Created by jlarrea on 19/07/2017.
 */
public class UsuarioResponse {
    private String id;
    private String token;
    private String id_usuario;
    private  String id_foto;

    public UsuarioResponse(String id, String token, String id_usuario, String id_foto) {
        this.id = id;
        this.token = token;
        this.id_usuario = id_usuario;
        this.id_foto = id_foto;
    }

    public UsuarioResponse() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getId_Usuario() {
        return id_usuario;
    }

    public void setId_Usuario(String id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getId_foto() {
        return id_foto;
    }

    public void setId_foto(String id_foto) {
        this.id_foto = id_foto;
    }
}
