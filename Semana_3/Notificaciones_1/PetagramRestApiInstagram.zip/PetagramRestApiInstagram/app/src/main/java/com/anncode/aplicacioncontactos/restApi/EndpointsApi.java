package com.anncode.aplicacioncontactos.restApi;

import com.anncode.aplicacioncontactos.restApi.model.ContactoResponse;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by anahisalgado on 25/05/16.
 */
public interface EndpointsApi {

    @GET(ConstantesRestApi.URL_GET_RECENT_MEDIA_USER)
    Call<ContactoResponse> getRecentMedia();

//    @GET(ConstantesRestApi.KEY_GET_RECENT_MEDIA_OTHER_USER + ConstantesRestApi.KEY_ACCESS_TOKEN + ConstantesRestApi.ACCESS_TOKEN)
//    Call<ContactoResponse> getRecentMedia();

}
