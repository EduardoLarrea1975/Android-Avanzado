package com.anncode.aplicacioncontactos.RestApiWebService;

import com.anncode.aplicacioncontactos.model.UsuarioResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by jlarrea on 18/07/2017.
 */
public interface Endpoint {

    @FormUrlEncoded
    @POST(ConstantesRestApi.KEY_POST_ID_TOKEN)
    Call<UsuarioResponse> registrarTokenID(@Field("token") String token);
}
