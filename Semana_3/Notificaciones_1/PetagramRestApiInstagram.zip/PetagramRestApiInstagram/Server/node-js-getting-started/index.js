var express = require('express');
var app = express();

app.set('port', (process.env.PORT || 5000));

var bodyParser = require("body-parser");
app.use(bodyParser.json());  //soporte para codificar json
app.use(bodyParser.urlencoded({ extended: true })); //Soporte para decodificar las URL

var firebase = require("firebase");
firebase.initializeApp({
   serviceAccount: "Petagram-8c24570f1ea9.json",
   databaseURL: "https://petagram-b3a93.firebaseio.com"
   });

app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function(request, response) {
  response.render('pages/index');
});


var tokenDeviceURI = "registrar-usuario";

//POST
//https://bibliotheque-croissant-44053.herokuapp.com/registrar-usuario
//token

app.post("/" + tokenDeviceURI, function(request, response) {
  var token = request.body.token;
  
  var db = firebase.database();
  var tokenDevices = db.ref(tokenDeviceURI).push();
  tokenDevices.set({
         token: token
  });

  var path = tokenDevices.toString();
  var pathSplit = path.split(tokenDeviceURI + "/");
  var idAutoGenerado = pathSplit[1];

  var respuesta = generarRespuestaAToken(db, idAutoGenerado);
  response.setHeader("Content-Type", "application/json");
  response.send(JSON.stringify(respuesta));

//  response.send(request.body.token);
});

function generarRespuestaAToken(db, idAutoGenerado) {
    var respuesta = {};
    var usuario = "";
    var ref = db.ref("registrar-usuario");
    ref.on("child_added", function(snapshot, prevChildKey) {
        usuario = snapshot.val();
        respuesta = {
        id: idAutoGenerado,
        token: usuario.token
        };
    })
    return respuesta;

}

app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});


